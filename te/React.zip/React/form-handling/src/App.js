import { BrowserRouter } from "react-router-dom";
import { routing } from "./router";

function App() {
  return (
   <>
    <BrowserRouter>
      {routing}
    </BrowserRouter>
   </>
  );
}

export default App;
