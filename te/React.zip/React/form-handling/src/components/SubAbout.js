import React, { Component } from 'react'
import { withRouter } from 'react-router-dom';

class SubAbout extends Component {
    render() {
       const {history} = this.props
        return (
            <div>
                <h1>Sub-About Component</h1>
                <button
                onClick={()=>{
                    history.push("/contacts")
                }}
                >Go to Contacts</button>
            </div>
        )
    }
}

export default  withRouter(SubAbout)
