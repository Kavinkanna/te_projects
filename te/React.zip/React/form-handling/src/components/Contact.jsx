import React from 'react'
import SubContact from './SubContact'

export default function Contact() {
    return (
        <div>
            <h1>Contact Us</h1>
            <SubContact />
        </div>
    )
}
