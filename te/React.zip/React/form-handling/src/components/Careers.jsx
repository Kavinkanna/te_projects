import React from 'react'
import { useHistory } from 'react-router-dom'

export default function Careers() {
//    const {state} = useLocation()
   const history = useHistory();
    return (
        <div>
            <h1>Careers Page</h1>
            {/* <h1>{state.name}</h1> */}

            <button
            onClick={()=>{ history.push("/home") }}
            >Go to Home</button>
        </div>
    )
}
