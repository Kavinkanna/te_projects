import React, { Component } from "react";

export default class Home extends Component {

    state = {
        email:"",
        pwd:""
    }
 

  handleSubmit =(event)=>{
      event.preventDefault();
        
      console.log(" form - handling");
      console.log("after form submission " ,this.state);
  }

  handleEmailChange =(event)=>{
    
    this.setState({
        email: event.target.value
    })
  }

  handlePasswordChange =(event)=>{
      this.setState({
          pwd:event.target.value
      })
  }

  render() {
    const { history } = this.props;
    return (
      <div>
        <h1>Home Page</h1>

        <button
          onClick={() => {
            history.push({
              pathname: "/careers",
              state: { name: "Punith" },
            });

            //  history.push("/career")
          }}
        >
          Go to Careers
        </button>

        <form className="container" onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="exampleInputEmail1">Email address</label>
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              value={this.state.email}
              onChange ={ this.handleEmailChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Password</label>
            <input
              type="password"
              className="form-control"
              id="exampleInputPassword1"
              value={this.state.pwd}
              onChange={this.handlePasswordChange}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    );
  }
}
