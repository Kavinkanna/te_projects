import React, { Component } from "react";

export default class About extends Component {

    state ={
        email:"",
        password:"",
        selected:"",
        checkBox:false ,
        demo:""
    }

    handleChange = (event) =>{
     
        if (event.target.type === "checkbox") {
         
            this.setState({
              checkBox : event.target.checked
            })
        }else{
          this.setState({
            [event.target.name] : event.target.value
        })
        }
      
    }

    handleSubmit =(event)=>{
        event.preventDefault();
        console.log(this.state);
    }


    handleDemo =(event,name)=>{
      console.log(event);
      this.setState({
            demo:name
      })

      console.log(this.state.demo);
    }

  render() {
    return (
      <div className="container">

          <input type="text" value={this.state.demo}  onChange={(event)=>{
            this.handleDemo(event ,"something")
          }}/>


        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="exampleInputEmail1">Email address</label>
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              value={this.state.email}
              onChange={this.handleChange}
              name="email"
            />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Password</label>
            <input
              type="password"
              className="form-control"
              id="exampleInputPassword1"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="exampleFormControlSelect1">Example select</label>
            <select className="form-control" id="exampleFormControlSelect1"
            name="selected"
            value={this.state.selected}
            onChange={this.handleChange}
            >
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
          </div>
          <div className="form-group form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="exampleCheck1"
              name="checkBox"
              checked={this.state.checkBox}
              onChange={this.handleChange}
            />
            <label className="form-check-label" htmlFor="exampleCheck1">
              Check me out
            </label>
          </div>

          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    );
  }
}
