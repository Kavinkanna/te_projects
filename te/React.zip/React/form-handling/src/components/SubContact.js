import { useHistory } from "react-router-dom";

export default function SubContact(props) {
  const history = useHistory();
  console.log(history);
  const goto = async () => {
    history.push("/about")
  };

  return (
    <div>
    
      <h1>Sub Contact Us</h1>
      <button onClick={goto}>Go to About Us</button>
     
    </div>
  );
}
