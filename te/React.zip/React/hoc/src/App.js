import { useState } from "react";
import { routing } from "./router";
import ButtonCounter from "./components/counters/ButtonCounter";
import InputCounter from "./components/counters/InputCounter";
import MouseCounter from "./components/counters/MouseCounter";

function App() {
  

  return (
    <>
      {/* <Infomations />
    <FunctionWithState   /> */}

      {/* <ButtonCounter  name="King" age={10} />
      <hr />
      <MouseCounter  />
      <hr></hr>
      <InputCounter  /> */}

      {routing}
    </>
  );
}

export default App;
