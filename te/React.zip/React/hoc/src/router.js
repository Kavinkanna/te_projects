import FunctionWithState from './components/FunctionWithState'
import Infomations from './components/Infomations'
import ButtonCounter from './components/counters/ButtonCounter'
import {Link ,BrowserRouter , Route ,Switch} from 'react-router-dom'

export const routing = (
  <BrowserRouter>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <Link class="navbar-brand" to="/">
        Home
      </Link>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <Link class="nav-link" to="/home">
              Home
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" to="/contact">
              Conatct
            </Link>
          </li>
        
    
        </ul>
      </div>
    </nav>

<Switch>
    <Route path="/"  exact component={FunctionWithState}/>
    <Route path="/contact"   component={Infomations  }/>
    <Route path="/"   component={ButtonCounter }/>
    </Switch>
  </BrowserRouter>
);
