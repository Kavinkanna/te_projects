import React, { PureComponent } from 'react'
import ClassComponent from './ClassComponent'
export default class Infomations extends PureComponent {
    state = {
        name:"Sharuk khan",
        profession:"Actor",
        age:55,
        home:"Mannath"
    }

    changeName=(newName)=>{
        this.setState({
            name:newName
        })
    }

    changeAge=()=>{
        this.setState({
            age:90
        })
    }


    render() {
       
        return (
            <div>
                <h2>{this.state.name}</h2>
                <h2>{this.state.age}</h2>
                <h2>{this.state.profession}</h2>
                <h2>{this.state.home}</h2>
                <button onClick={()=>{
                    this.changeName("Ameer Khan")}
                }>Change Name</button>

                <button onClick={this.changeAge}>Change Age</button>

                <ClassComponent />
            </div>
        )
    }
}
