import React, { Component } from "react";
import { withRouter } from "react-router-dom";

class ClassComponent extends Component {
  render() {
    console.log(this.props.history);
    return (
      <div>
        <button>Go to Home</button>
      </div>
    );
  }
}

export default withRouter(ClassComponent);
