import React, { useState } from 'react'

function FunctionWithState(props) {

    let [count, setCount] = useState(0);
    let [isMarried, setIsMarried] = useState(false)
    let [hobbies, setHobbies] = useState(["criket" ,"basketBall" ])

    function add(){
        hobbies.push("Football")
        setHobbies([...hobbies])
    }
    return (
        <div>
            {count}
            <br />
            Married : {isMarried ?"Yes": "No"}
            {
                hobbies.map((data)=>{
                    return <p key={data}>{data}</p>
                })
            }

            <button onClick={()=>{
               setCount(count+1)
            }}>Increment</button>

            <button
                onClick={()=>{
                    setIsMarried(!isMarried)
                }}
            
            >Change Status</button>

            <button  onClick={add}>Add Hobbies</button>
        </div>
    )
}

export default React.memo(FunctionWithState)