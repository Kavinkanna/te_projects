import React, { Component } from 'react'
import withCounter from '../../hoc/withCounter'

class MouseCounter extends Component {
    
    
    render() {
        console.log(this.props);
        let {count , increment} = this.props
        return (
            <div>
                <h1  
                onMouseOver={()=>{
                   increment()
                }}
                >{count} </h1>

            </div>
        )
    }
}

export default  withCounter(MouseCounter)