import React  from 'react'
import withCounter from '../../hoc/withCounter';

 function InputCounter(props) {
  let {count , increment} = props;
    return (
        <div>
            <h1>
                <input value={count} onChange={()=>{
                   increment()
                }} />
            </h1>
        </div>
    )
}
export default withCounter(InputCounter)