import React, { Component } from "react";
import withCounter from "../../hoc/withCounter";
import FunctionComponent from "../FunctionComponent";
 class ButtonCounter extends Component {
  
  render() {
      console.log(this.props);
      let {count , increment} = this.props
	  
    return (
      <div>
          
        <h1>{count} - {this.props.name}</h1>
        <button
          onClick={() => {
           increment()
          }}
        >
          Increment
        </button>

        <FunctionComponent />
      </div>
    );
  }
}

export default withCounter(ButtonCounter)