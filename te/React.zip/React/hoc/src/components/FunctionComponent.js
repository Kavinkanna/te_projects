import React from "react";
import { useHistory } from "react-router-dom";

export default function FunctionComponent(props) {
  console.log(props);
  const history = useHistory();
  console.log(history);
  return (
    <div>
      <button>Go</button>
    </div>
  );
}
