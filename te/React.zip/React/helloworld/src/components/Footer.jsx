
function Footer(props){
    console.log("fn cmp",props);
    return <div>
        <h1>This is Function component {props.name}</h1>
    </div>
}

export default Footer;