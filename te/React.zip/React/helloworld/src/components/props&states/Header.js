import React, { Component } from "react";

export default class Header extends Component {
  constructor(props) {
    super(props);
    const {name} = {...props}
    console.log(name);
    this.state = {
     name,
      age: 10,
    };
  }

  render() {
    // if (this.props.name === "Joker") {
    //     this.props.name = "King"
    // }
    console.log(this.state); //Joker 10
    return (
      <div>
        <h1> Name is : {this.state.name} </h1>

        <button
          onClick={() => {
            if (this.state.name === "Joker") {
              //     this.setState({
              //        name:"Kiran"
              //    })

              this.setState((prevState) => ({
                name: "kiran " + prevState.age,
              }));

              console.log("after setState", this.state); // Kiran 10
            }
          }}
        >
          Change Name
        </button>
      </div>
    );
  }
}
