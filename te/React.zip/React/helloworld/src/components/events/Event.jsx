import React, { Component } from 'react'

export default class Event extends Component {
    
    constructor(props){
        super(props)

        this.state ={
            name:"Chris Evans"
        }

        // this.handleClick = this.handleClick.bind(this); //1
    }

    // handleClick (){
    //     this.setState({
    //         name:"Chris Hemsworth "
    //     })
    // }

    handleClick = ()=>{
        this.setState({
            name:"Arrow Function"
        })
    }

    render() {
        return (
            <div>
                <h1> {this.state.name} </h1>
            {/* <button  onClick={this.handleClick.bind(this)} >change name</button> 2  */} 
            {/* <button  onClick={()=>{
                this.handleClick()                      3
            }} >change name</button> */}
             <button  onClick={this.handleClick} >change name</button>
            </div>
        )
    }
}
//onclick -> onClick
//onmouseover -> onMouseOver

//onclick="methodname"