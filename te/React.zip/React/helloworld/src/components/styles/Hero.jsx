
import React, { Component } from 'react'
import   './hero.css'
export default class Hero extends Component {

    render() {
        const styles = {
            backgroundColor:"black",
            color:"white",
            margin:"auto",
            textAlign:"center",
        }
        return (
            <div>
                <h1 style={
                    {
                        backgroundColor:"yellow",
                        fontSize:"30PX",
                        color:"teal",
                        textAlign:"center",
                        margin: "auto"
                    }
                } > Hey this is Awesome</h1>

                <br />
                <hr />

                <h1 style={styles}>React JS Sessions</h1> 

                <br />
                <hr />

                <h1 id="hero"> Mern stack Batch - 13 </h1> 

              
             
            </div>
        )
    }
}

//font-family --> fontFamily
//text-transformation --> textTransformation