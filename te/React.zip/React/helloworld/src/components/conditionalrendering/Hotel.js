import React, { Component } from 'react'

export default class Hotel extends Component {

    render() {
        if (this.props.type === "veg") {
            return (
                <div>
                    <ol>
                        <li>Mutter Paneer</li>
                        <li>Khaju kurma</li>
                        <li>Dhal Dadka</li>
                        <li>Veg kurma</li>
                        <li>veg palav</li>
                        <li>patato bujiya</li>
                        <li>Gobi manchurian</li>
                    </ol>
                </div>
            )
        } else {
            return(
                <div>
                <ol>
                   <li>Butter Chicken</li>
                   <li>Chicken Kurma</li>
                   <li>mutton biryani</li>
                   <li>Chicken lollipop </li>
                </ol>
            </div>   
            )
        }
    }
}
