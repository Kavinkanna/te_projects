import React, { Component } from 'react'
import Child from './Child'

export default class Parent extends Component {
    state={
        course:"javaScript"
    }

    changeCourse= (newCo)=>{
        console.log("Data from Child Component ", newCo);
        let newCourse = prompt("Enter the Course")
        if (newCourse != null) {
            this.setState({
                course:newCourse
            })
        }
    }

    render() {
        return (
            <>
                <h1>Course Name : {this.state.course}</h1>
                <Child action={this.changeCourse} />
            </>
        )
    }
}
