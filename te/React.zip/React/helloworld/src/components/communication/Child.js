import React, { Component } from "react";

export default class Child extends Component {
  render() {
    return (
      <>
        <>
          <button
            onClick={() => {
              this.props.action("Node");
            }}
          >
            Change Course
          </button>
        </>
        <>
          <h1> This is Child to Parent Component communication</h1>
        </>
      </>
    );
  }
}
