import React, { Component } from "react";
import EmployeeInfo from "./EmployeeInfo";

export default class Employees extends Component {
  state = {
    employees: [
      {
        id: 1,
        name: "Rakesh",
        designation: "Intern",
      },
      {
        id: 2,
        name: "Akhil",
        designation: "Developer",
      },
      {
        id: 3,
        name: "Mahes",
        designation: "Testing",
      },
      {
        id: 4,
        name: "Maruti",
        designation: "Intern",
      },
      {
        id: 5,
        name: "Hasib",
        designation: "Developer",
      },
    ],
  };


  render() {
    return (
      <div className="container">
        <table className="table table-striped table-dark">
          <thead>
            <tr>
              <th scope="col">SI NO</th>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Designation</th>

            </tr>
          </thead>
          <tbody>
              {
                  this.state.employees.map((data)=>{
                      return (
                          <EmployeeInfo info={data} key={data.id} />
                      )
                  })
              } 
          </tbody>
        </table>
      </div>
    );
  }
}
