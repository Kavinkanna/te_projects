import { Component } from "react";

export default class Home extends Component {
  constructor(props) {
    super(props);
    console.log(this.props);
  }

  render() {
    return (
      <div>
        <ul>
          {this.props.content.map((ele) => {
            return <li key={ele}>{ele}</li>;
          })}
        </ul>
        <h1>{this.props.name} </h1>
      </div>
    );
  }
}
