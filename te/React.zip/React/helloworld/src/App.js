import React, { Component } from "react";
import Hotel from "./components/conditionalrendering/Hotel";


export default class App extends Component {
  state = {
    foodType: "veg",
    isloggedIn: false,
  };

  changeMenu = () => {
    this.setState((prevState) => {
      if (prevState.foodType === "veg") {
        return {
          foodType: "nonveg",
        };
      } else {
        return {
          foodType: "veg",
        };
      }
    });
  };
  render() {
    return (
      <div>
      
        <Hotel type={this.state.foodType} />

        <button onClick={this.changeMenu}>
          {this.state.foodType === "veg" ? "Show NonVeg Menu" : "Show Veg menu"}{" "}
        </button>

        <button
          onClick={() => {
            this.setState((prev) => {
              return {
                isloggedIn: !prev.isloggedIn,
              };
            });
          }}
        >
          {this.state.isloggedIn ? "Logout" : "Login"}{" "}
        </button>
      </div>
    );
  }
}
