import { useState } from "react";
import { AnimatedSwitch } from "react-router-transition";
import {LoginProvider} from './context/loginContext'
import { routing } from "./router";
import './App.css'
import { BrowserRouter as Router} from "react-router-dom";


function App() {
  const [login, setLogin] = useState(false);

  const logout =()=>{
    setLogin(false)
  }

  const changeLogin =()=>{
    setLogin(true)
  }

  const loginInfo = {
    login:login,
    logout:logout,
    changeLogin:changeLogin
  }
  return (
    <Router >
    <LoginProvider value={loginInfo} >
      <AnimatedSwitch
       atEnter={{ opacity: 0 }}
       atLeave={{ opacity: 0 }}
       atActive={{ opacity: 1 }}
       className="switch-wrapper"
      >
      {routing}

      </AnimatedSwitch>
    </LoginProvider>
    </Router>
  );
}

export default App;
