import axios from "axios";
import { useEffect, useState } from "react";

export default function useFetch(url) {
  let [data, setData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.get(url);
      console.log(res);
      setData(res.data);
    };

    fetchData();
  }, [url]);

  return [data , setData];
}
