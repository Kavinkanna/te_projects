import React, { useContext } from 'react'
import { useHistory } from 'react-router-dom';
import LoginContext from '../context/loginContext'

export default function Login() {
    const context = useContext(LoginContext);
    const history = useHistory();

    const login =()=>{
        console.log(context);
        context.changeLogin(true);
        console.log(context.login);
        localStorage.setItem("session" , true)
        history.push("/")
    }
    return (
        <div>
            <h1> Login Here</h1>

            <button  onClick={login}>Login</button>
        </div>
    )
}
