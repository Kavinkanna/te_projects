import axios from 'axios';
import React, { useEffect, useState } from 'react'
import useFetch from '../customehooks/useFetch';

export default function SimpleFC() {
   
    let [count, setCount] = useState(0);
    let [name, setName] = useState("KK");

    const [data,setData] = useFetch('https://jsonplaceholder.typicode.com/users')
    console.log(data);
    

   //equivalent to CDM
    // useEffect(()=>{
    //     console.log("CDM");
    // },[])

    // //CDU
    // useEffect(()=>{
    //     console.log("CDU");
    // },[count,name])

    // //CWUM
    // useEffect(()=>{
    //     return ()=>{
    //         //clean up process
    //         console.log("unmounted");
    //     }
    // },[])

    useEffect(() => {
        console.log("CDM");
        
        return () => {
            console.log("unmounted");
        }
    }, [])

    useEffect(()=>{
        console.log("CDU");
    },[name, count])

    return (
        <div>
            <h1>Life Cycle Example</h1>

            <h3 onClick={()=>{
                setCount(++count);
            }}  >{count}</h3>

            <h1
            onClick={()=>{
                setName("LOKI")
            }}
            >{name}</h1>

            <button onClick={()=>{
                setData([])
                console.log(data);
            }}>Click to make it Empty</button>
        </div>
    )
}
