import axios from "axios";
import React, { Component } from "react";

export default class Home extends Component {
  state = {
    users: null,
    isLoading: false,
  };
  getData = async () => {
    this.setState({
      isLoading: true,
    });
    await this.fetchData("https://jsonplaceholder.typicode.com/users").then(
      (data) => {
        this.setState({
          users: data,
        });
      }
    );

    this.setState({
      isLoading: false,
    });
  };

  fetchData = (url) => {
    const myPromise = new Promise((resolve, reject) => {
      setTimeout(() => {
        // fetch(url).then((resp)=>{
        //     resolve(resp.json())
        // }).catch((err)=>{
        //     reject(err);
        // })
        axios
          .get(url)
          .then((resp) => {
            resolve(resp.data);
          })
          .catch((err) => {
            console.log(err);
          });
      }, 5000);
    });

    return myPromise;
  };

  storeData = () => {
    axios.post(
      "https://jsonplaceholder.typicode.com/posts",
      {
        title: "foo",
        body: "bar",
        userId: 1,
      },
      {
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      }
    ).then((resp)=>{
        console.log(resp);
    });



    axios.put('https://jsonplaceholder.typicode.com/posts/1' , 
    {
        id: 1,
        title: 'foo',
        body: 'bar',
        userId: 1,
      },
      {
        headers: {
            'Content-type': 'application/json; charset=UTF-8',
          }
      }
    ).then(resp=>{
        console.log(resp);
    })


    axios.delete('https://jsonplaceholder.typicode.com/posts/1').then((resp)=>{
        console.log(resp);
    })
  };
  render() {
    return (
      <div>
        {this.state.isLoading ? (
          <div
            style={{
              background: "lightgreen",
            }}
          >
            "this is loading"
          </div>
        ) : null}
        <button onClick={this.storeData}>Store Data</button>
        <button onClick={this.getData}>Get Data</button>
        {this.state.users == null
          ? null
          : this.state.users.map((data) => {
              return (
                <>
                  <h1>{data.name}</h1>
                  <h2>{data.email}</h2>
                  <hr></hr>
                </>
              );
            })}
      </div>
    );
  }
}
