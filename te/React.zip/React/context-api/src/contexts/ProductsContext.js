import React from 'react'

const productContext = React.createContext();
const ProductProvider = productContext.Provider
const ProductConsumer = productContext.Consumer


export {ProductConsumer , ProductProvider}
export default productContext