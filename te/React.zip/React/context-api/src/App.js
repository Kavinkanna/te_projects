import { useState } from "react";
import ProductsFour from "./components/ProductsFour";
import ProductsTwo from "./components/ProductsTwo";
import { ProductProvider } from "./contexts/ProductsContext";

function App() {
  const [products, setProducts] = useState([
    "laptop",
    "mobile",
    "Tabs",
    "bat",
    "Mouse",
    "TV",
    "Keyboard",
  ]);

  const getData = (data) => {
    alert(data);
  };

  let data = {
    products: products,
    getData: getData,
  };

  return (
    <div>
      <ProductProvider value={data}>
        <ProductsTwo />
        
        <ProductsFour />
      </ProductProvider>
    </div>
  );
}

export default App;
