import React from 'react'
import ProductsThree from './ProductsThree'

export default function ProductsTwo() {
    return (
        <div>
            <ProductsThree />
          
        </div>
    )
}
