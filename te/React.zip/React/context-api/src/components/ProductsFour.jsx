import React, { useContext } from "react";
import productContext from "../contexts/ProductsContext";

export default function ProductsFour() {

  const productDetails = useContext(productContext);
  console.log(productDetails);//
  return <div>
      {
        productDetails.products.map((data)=>{
          return <h5 key={data} onClick={()=>{
            productDetails.getData(data)
          }}>{data}</h5>
        })
      }
  </div>;
}
