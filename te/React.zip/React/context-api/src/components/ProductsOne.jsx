import React from 'react'
import ProductsTwo from './ProductsTwo'

export default function ProductsOne() {
    return (
        <div>
            <ProductsTwo  />
        </div>
    )
}
