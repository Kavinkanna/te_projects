import React from "react";
import { ProductConsumer } from "../contexts/ProductsContext";

export default function ProductsThree() {
  return (
    <div>
      <ProductConsumer>
        {(info) => {
          return (
            <ul>
              {info.products.map((data) => {
                return (
                  <li
                    onClick={() => {
                      info.getData(data);
                    }}
                    key={data}
                  >
                    {data}
                  </li>
                );
              })}
            </ul>
          );
        }}
      </ProductConsumer>
    </div>
  );
}
